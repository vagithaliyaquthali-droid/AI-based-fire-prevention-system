#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <SPI.h>
#include <SD.h>

// ================= PIN MAP =================
#define MQ2_PIN       32
#define ACS712_PIN    34
#define ZMPT_PIN      35

#define RELAY_PIN     26
#define BUZZER_PIN    27

#define LCD_SDA       21
#define LCD_SCL       22

#define SD_CS         5
#define SD_SCK        18
#define SD_MISO       19
#define SD_MOSI       23

// SIM800L connections: modem TX -> ESP32 RX, modem RX -> ESP32 TX.
#define SIM800_RX_PIN 16
#define SIM800_TX_PIN 17
#define SIM800_BAUD   9600

const char PHONE_NUMBER[] = "+919176721644";

// ================= LCD =================
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ================= SD =================
SPIClass spi = SPI;
bool sdOK = false;

// ================= SIM800L =================
HardwareSerial sim800(2);
bool modemReady = false;

enum SmsStage {
  SMS_IDLE,
  SMS_WAITING_FOR_PROMPT,
  SMS_WAITING_FOR_RESULT
};

SmsStage smsStage = SMS_IDLE;
String smsResponse;
String queuedSmsText;
String activeSmsText;
unsigned long smsDeadline = 0;

// ================= SETTINGS =================
const float ADC_VREF = 3.3;
const int ADC_MAX = 4095;

// Your 10k/20k divider
const float DIVIDER_FACTOR = 1.5;

// MQ-2 demonstration thresholds
// Based on your tested clean-air raw value ~1500
const int MQ_WARNING = 2200;
const int MQ_CRITICAL = 3000;

// Electrical anomaly thresholds are DEMO thresholds.
// They are based on signal deviation, not calibrated amperage/voltage.
const int ACS_WARNING_DELTA = 180;
const int ACS_CRITICAL_DELTA = 350;

// =================================================
// RELAY LOGIC
// Your tested relay:
// HIGH = OFF
// LOW  = ON
// =================================================

void powerOFF() {
  digitalWrite(RELAY_PIN, HIGH);
}

void powerON() {
  digitalWrite(RELAY_PIN, LOW);
}

// =================================================
// LCD STATUS
// =================================================

void showStatus(String line1, String line2) {

  lcd.clear();

  lcd.setCursor(0, 0);
  lcd.print(line1);

  lcd.setCursor(0, 1);
  lcd.print(line2);
}

// =================================================
// SD LOG
// =================================================

void logEvent(String eventText, int mq, int acs, int zmpt) {

  if (!sdOK)
    return;

  File file = SD.open("/hazard_log.txt", FILE_APPEND);

  if (file) {

    file.print("MQ2=");
    file.print(mq);

    file.print(", ACS=");
    file.print(acs);

    file.print(", ZMPT=");
    file.print(zmpt);

    file.print(", EVENT=");
    file.println(eventText);

    file.close();
  }
}

// =================================================
// SIM800L SMS
// =================================================

bool waitForModemResponse(const char *expected, unsigned long timeoutMs) {

  String response;
  unsigned long startedAt = millis();

  while (millis() - startedAt < timeoutMs) {

    while (sim800.available()) {
      char c = sim800.read();
      response += c;

      if (response.indexOf(expected) >= 0)
        return true;

      if (response.indexOf("ERROR") >= 0)
        return false;

      if (response.length() > 160)
        response.remove(0, 80);
    }

    delay(10);
  }

  return false;
}

bool initializeModem() {

  sim800.begin(SIM800_BAUD, SERIAL_8N1, SIM800_RX_PIN, SIM800_TX_PIN);
  sim800.setTimeout(1000);
  delay(1000);

  while (sim800.available())
    sim800.read();

  bool modemResponded = false;

  for (int attempt = 0; attempt < 5; attempt++) {
    sim800.println("AT");

    if (waitForModemResponse("OK", 1000)) {
      modemResponded = true;
      break;
    }

    delay(300);
  }

  if (!modemResponded) {
    Serial.println("SIM800L: no AT response; check power, baud rate, and UART wiring.");
    return false;
  }

  sim800.println("AT+CMGF=1");

  if (!waitForModemResponse("OK", 2000)) {
    Serial.println("SIM800L: could not enable SMS text mode.");
    return false;
  }

  Serial.println("SIM800L: ready for SMS.");
  return true;
}

void requestSMS(String message) {

  if (!modemReady) {
    Serial.println("SMS not sent: SIM800L is not ready.");
    return;
  }

  if (PHONE_NUMBER[0] != '+') {
    Serial.println("SMS not sent: set PHONE_NUMBER to an international number starting with +.");
    return;
  }

  if (smsStage != SMS_IDLE || queuedSmsText.length() > 0) {
    queuedSmsText = message;
    Serial.println("SMS queued; another SMS is still in progress.");
    return;
  }

  queuedSmsText = message;
}

void serviceSMS() {

  while (sim800.available()) {
    char c = sim800.read();

    if (smsResponse.length() < 240)
      smsResponse += c;

    if (smsStage == SMS_WAITING_FOR_PROMPT && c == '>') {
      sim800.print(activeSmsText);
      sim800.write(26);
      smsResponse = "";
      smsStage = SMS_WAITING_FOR_RESULT;
      smsDeadline = millis() + 20000;
      Serial.println("SIM800L: SMS submitted; waiting for network confirmation.");
    }
  }

  if (smsStage == SMS_WAITING_FOR_PROMPT && smsResponse.indexOf("ERROR") >= 0) {
    Serial.println("SIM800L rejected the SMS command.");
    smsStage = SMS_IDLE;
    activeSmsText = "";
    smsResponse = "";
  }
  else if (smsStage == SMS_WAITING_FOR_RESULT) {

    if (smsResponse.indexOf("ERROR") >= 0) {
      Serial.println("SIM800L failed to send SMS; check SIM, signal, and network registration.");
      smsStage = SMS_IDLE;
      activeSmsText = "";
      smsResponse = "";
    }
    else if (smsResponse.indexOf("+CMGS:") >= 0 &&
             smsResponse.indexOf("OK") >= 0) {
      Serial.println("SIM800L confirmed SMS sent.");
      smsStage = SMS_IDLE;
      activeSmsText = "";
      smsResponse = "";
    }
  }

  if (smsStage != SMS_IDLE &&
      static_cast<long>(millis() - smsDeadline) >= 0) {
    Serial.println("SIM800L SMS timed out; check signal, SIM, and power supply.");
    smsStage = SMS_IDLE;
    activeSmsText = "";
    smsResponse = "";
  }

  if (smsStage == SMS_IDLE && queuedSmsText.length() > 0) {
    activeSmsText = queuedSmsText;
    queuedSmsText = "";
    smsResponse = "";

    sim800.print("AT+CMGS=\"");
    sim800.print(PHONE_NUMBER);
    sim800.println("\"");

    smsStage = SMS_WAITING_FOR_PROMPT;
    smsDeadline = millis() + 10000;
    Serial.println("SIM800L: requesting SMS prompt.");
  }
}

// =================================================
// SETUP
// =================================================

void setup() {

  Serial.begin(115200);
  delay(1000);

  analogReadResolution(12);

  // Relay
  pinMode(RELAY_PIN, OUTPUT);
  powerOFF();

  // Buzzer
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  // LCD
  Wire.begin(LCD_SDA, LCD_SCL);

  lcd.init();
  lcd.backlight();

  showStatus("AI FIRE SAFETY", "SYSTEM STARTING");

  delay(1500);

  // SD
  spi.begin(SD_SCK, SD_MISO, SD_MOSI, SD_CS);

  if (SD.begin(SD_CS, spi, 1000000)) {

    sdOK = true;

    File file = SD.open("/hazard_log.txt", FILE_APPEND);

    if (file) {
      file.println();
      file.println("===== SYSTEM STARTED =====");
      file.close();
    }

  } else {

    sdOK = false;
  }

  showStatus("SYSTEM STATUS", "SAFE");

  delay(1500);

  Serial.println();
  Serial.println("====================================");
  Serial.println("     AI FIRE SAFETY SYSTEM");
  Serial.println("       FINAL DEMO VERSION");
  Serial.println("====================================");

  if (sdOK)
    Serial.println("SD CARD: OK");
  else
    Serial.println("SD CARD: ERROR");

  Serial.println("System monitoring started.");

  modemReady = initializeModem();

  if (!modemReady)
    Serial.println("SMS alerts unavailable; sensor, relay, and buzzer monitoring continue.");
}

// =================================================
// LOOP
// =================================================

void loop() {

  serviceSMS();

  // =================================================
  // READ SENSORS
  // =================================================

  int mqRaw = analogRead(MQ2_PIN);
  int acsRaw = analogRead(ACS712_PIN);
  int zmptRaw = analogRead(ZMPT_PIN);

  // =================================================
  // VOLTAGE REPRESENTATION
  // =================================================

  float mqPinVoltage =
    (mqRaw * ADC_VREF) / ADC_MAX;

  float acsPinVoltage =
    (acsRaw * ADC_VREF) / ADC_MAX;

  float zmptPinVoltage =
    (zmptRaw * ADC_VREF) / ADC_MAX;

  float mqSensorVoltage =
    mqPinVoltage * DIVIDER_FACTOR;

  float acsSensorVoltage =
    acsPinVoltage * DIVIDER_FACTOR;

  float zmptSensorVoltage =
    zmptPinVoltage * DIVIDER_FACTOR;

  // =================================================
  // ACS BASELINE
  // =================================================
  // Your tested no-load region is around 2800.
  // This is only used for demonstration anomaly detection.

  int acsDeviation = abs(acsRaw - 2800);

  // =================================================
  // HAZARD DETECTION
  // =================================================

  bool smokeWarning = false;
  bool smokeCritical = false;

  bool electricalWarning = false;
  bool electricalCritical = false;

  // -------- SMOKE --------

  if (mqRaw >= MQ_WARNING)
    smokeWarning = true;

  if (mqRaw >= MQ_CRITICAL)
    smokeCritical = true;

  // -------- ELECTRICAL --------

  if (acsDeviation >= ACS_WARNING_DELTA)
    electricalWarning = true;

  if (acsDeviation >= ACS_CRITICAL_DELTA)
    electricalCritical = true;

  // =================================================
  // DETERMINE SYSTEM STATE
  // =================================================

  String state = "SAFE";

  if (smokeCritical || electricalCritical) {

    state = "CRITICAL";

  }
  else if (smokeWarning || electricalWarning) {

    state = "WARNING";

  }

  // =================================================
  // SAFE
  // =================================================

  if (state == "SAFE") {

    powerON();

    digitalWrite(BUZZER_PIN, LOW);

    showStatus(
      "SYSTEM STATUS",
      "SAFE"
    );
  }

  // =================================================
  // WARNING
  // =================================================

  else if (state == "WARNING") {

    powerON();

    // Intermittent buzzer
    digitalWrite(BUZZER_PIN, HIGH);
    delay(150);
    digitalWrite(BUZZER_PIN, LOW);

    if (smokeWarning && electricalWarning) {

      showStatus(
        "WARNING!",
        "MULTI HAZARD"
      );

    }
    else if (smokeWarning) {

      showStatus(
        "WARNING!",
        "SMOKE DETECTED"
      );

    }
    else {

      showStatus(
        "WARNING!",
        "ELEC HAZARD"
      );
    }
  }

  // =================================================
  // CRITICAL
  // =================================================

  else {

    // IMMEDIATE POWER CUT
    powerOFF();

    // Alarm
    digitalWrite(BUZZER_PIN, HIGH);

    if (smokeCritical && electricalCritical) {

      showStatus(
        "CRITICAL ALERT!",
        "FIRE+ELECTRICAL"
      );

    }
    else if (smokeCritical) {

      showStatus(
        "FIRE ALERT!",
        "SMOKE DETECTED"
      );

    }
    else {

      showStatus(
        "CRITICAL!",
        "POWER CUT OFF"
      );
    }
  }

  // =================================================
  // SERIAL MONITOR
  // =================================================

  Serial.println("--------------------------------");

  Serial.print("MQ2 RAW       : ");
  Serial.println(mqRaw);

  Serial.print("MQ2 SENSOR V  : ");
  Serial.println(mqSensorVoltage, 2);

  Serial.print("ACS712 RAW    : ");
  Serial.println(acsRaw);

  Serial.print("ACS DEVIATION : ");
  Serial.println(acsDeviation);

  Serial.print("ZMPT RAW      : ");
  Serial.println(zmptRaw);

  Serial.print("ZMPT SENSOR V : ");
  Serial.println(zmptSensorVoltage, 2);

  Serial.print("SYSTEM STATE  : ");
  Serial.println(state);

  Serial.print("SD            : ");
  Serial.println(sdOK ? "OK" : "ERROR");

  // =================================================
  // SD EVENT LOG
  // =================================================

  static String previousState = "START";

  if (state != previousState) {

    logEvent(
      state,
      mqRaw,
      acsRaw,
      zmptRaw
    );

    if (state != "SAFE" || previousState != "START") {
      String message;

      if (state == "SAFE") {
        message = "ALL CLEAR: Fire/electrical safety system returned to SAFE.";
      }
      else {
        message = "ALERT: System state " + state +
                  ". MQ2 raw=" + String(mqRaw) +
                  ", ACS712 raw=" + String(acsRaw) + ".";
      }

      requestSMS(message);
    }

    previousState = state;
  }

  // Periodic logging
  static unsigned long lastLog = 0;

  if (millis() - lastLog >= 5000) {

    lastLog = millis();

    logEvent(
      state,
      mqRaw,
      acsRaw,
      zmptRaw
    );
  }

  // =================================================
  // LOOP DELAY
  // =================================================

  delay(500);
}